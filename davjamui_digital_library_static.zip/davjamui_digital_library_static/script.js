
// Demo client-side search and sample data
const DEMO = [];
for(let i=1;i<=30;i++){
  DEMO.push({
    id:i,
    title:`Sample Book ${i} — Mathematics (Class ${i%12+1})`,
    author:`Author ${i%7+1}`,
    type: ['book','video','audio','paper'][i%4],
    grade: ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'][i%12],
    year:2020 + (i%6),
    thumbnail: 'assets/photo1.jpg',
    description: 'Short description for sample resource '+i,
    file_url: '#'
  })
}
let state = {q:'',type:'all',page:1,per_page:6,results:[],total:0}

function doSearch(){
  const q = (document.getElementById('q').value||'').trim();
  const type = document.getElementById('typeFilter').value;
  state.q=q; state.type=type; state.page=1;
  serverSearch(q,type,state.page,state.per_page).then(res=>{ state.results=res.results; state.total=res.total; renderResults(); })
}

async function serverSearch(q,type,page,per_page){
  // Simulate server filtering
  const filtered = DEMO.filter(item=>{
    if(type && type!=='all' && item.type!==type) return false;
    if(q){ const s=(item.title+item.author+item.description+item.grade).toLowerCase(); if(!s.includes(q.toLowerCase())) return false }
    return true;
  });
  const total = filtered.length;
  const start = (page-1)*per_page; const results = filtered.slice(start,start+per_page);
  await new Promise(r=>setTimeout(r,120));
  return {total,results};
}

function renderResults(){
  const list = document.getElementById('results'); list.innerHTML='';
  if(!state.results.length){ list.innerHTML='<div class="card">No results found.</div>'; return; }
  state.results.forEach(it=>{
    const el = document.createElement('div'); el.className='card resource';
    el.innerHTML = `<div class="thumb"><img src="${it.thumbnail}" style="width:100%;height:100%;object-fit:cover;border-radius:6px" /></div>
      <div style="flex:1"><h3>${esc(it.title)}</h3><div class="meta">${esc(it.author)} • ${esc(it.type)} • Grade: ${esc(it.grade)}</div><p>${esc(it.description)}</p>
      <div style="margin-top:8px"><button onclick="viewItem(${it.id})">View</button> <button onclick="downloadItem(${it.id})">Download</button></div></div>`;
    list.appendChild(el);
  })
  document.querySelector('.pager')?.scrollIntoView({behavior:'smooth'});
}

function esc(s){ return (s||'').toString().replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#039;"}[m])) }

function viewItem(id){ const it = DEMO.find(x=>x.id===id); if(!it) return alert('Not found'); alert(it.title + '\n\n' + it.description); }
function downloadItem(id){ alert('Download: Item ID '+id) }

function prevPage(){ if(state.page>1){ state.page--; doSearchPage(); } }
function nextPage(){ const max = Math.ceil(state.total/state.per_page); if(state.page<max){ state.page++; doSearchPage(); } }
function doSearchPage(){ serverSearch(state.q,state.type,state.page,state.per_page).then(res=>{ state.results=res.results; state.total=res.total; renderResults(); }) }

function setFilter(k,v){ /* sample: only grade/subject implemented in UI chips */ const input = document.getElementById('q'); input.value = v; doSearch(); }

// initial render
(async ()=>{ const res = await serverSearch('', 'all', 1, 6); state.results=res.results; state.total=res.total; renderResults(); })();
